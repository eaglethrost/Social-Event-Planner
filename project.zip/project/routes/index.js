var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var con = mysql.createPool({
  host: 'localhost',
  database: 'EventsPlanner'
});


/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { month: 'june' });
});

router.get('/about', function (req, res, next) { 
  res.render('about.html', { title: 'about' });
});

router.get('/contact', function (req, res, next) {
  res.render('contact.html', { title: 'contact' });
});

router.get('/faq', function (req, res, next) {
  res.render('faq.html', { title: 'faq' });
});

router.get('/signup', function (req, res, next) {
  res.render('signup.html', { title: 'faq' });
});

router.get('/login', function (req, res, next) {
  res.render('login.html', { title: 'faq' });
});

router.post('/user-login', function (req, res, next) {
  con.getConnection(function (err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "SELECT * FROM Users WHERE email_id = '" + req.body.userEmail + "' AND user_password = '" + req.body.userPassword + "';";
    console.log(sql);
    con.query(sql, function (err, result, fields) {
      if (err) throw err;
      console.log(fields);
      console.log(result);
    });
  });
  // console.log(result);
  res.redirect('/');
});


router.post('/form-submit', function (req, res, next) {
  if (req.body.userName === '') {
    res.redirect('/signup');
  }
  if (req.body.userFamilyName === '') {
    res.redirect('/signup');
  }
  if (req.body.userEmail) {
    res.redirect('/signup');
  }
  if (req.body.userPhone.length) {
    res.redirect('/signup');
  }
  if (req.body.userPassword != req.body.userConfirmPassword) {
    res.redirect('/signup');
  }

  con.getConnection(function (err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO Users (first_name, last_name, email_id, phone_no, user_password) VALUES ?";
    var values = [
      [req.body.userName, req.body.userFamilyName, req.body.userEmail, req.body.userPhone, req.body.userPassword]
    ];
    con.query(sql, [values], function (err, result) {
      if (err) throw err;
      console.log("Number of records inserted: " + result.affectedRows);
    });
  });
  console.log(req.body);
  res.redirect('/');
});


router.post('/create-event', function(req, res, next) {
  con.getConnection(function (err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO Events (event_title, last_name, email_id, phone_no, user_password) VALUES ?";
    var values = [
      [req.body.userName, req.body.userFamilyName, req.body.userEmail, req.body.userPhone, req.body.userPassword]
    ];
    con.query(sql, [values], function (err, result) {
      if (err) throw err;
      console.log("Number of records inserted: " + result.affectedRows);
    });
  });
  console.log(req.body);
  res.redirect('/');

});



module.exports = router;


