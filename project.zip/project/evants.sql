CREATE DATABASE EventsPlanner;
USE EventsPlanner;


CREATE TABLE Admins (
    admin_id int AUTO_INCREMENT,
    first_name varchar(20),
    last_name varchar(20),
    PRIMARY KEY(admin_id)
);

CREATE TABLE Users (
    user_id int AUTO_INCREMENT,
    first_name varchar(20),
    last_name varchar(20),
    email_id varchar(50),
    phone_no int,
    user_password varchar(50),
    PRIMARY KEY(user_id)
);

CREATE TABLE Calendar (
    user_id int,
    event_start_date_time DATETIME,
    PRIMARY KEY(event_start_date_time),
    FOREIGN KEY(user_id) REFERENCES Users(user_id)
);

CREATE TABLE Participants (
    view_id int,
    user_id int,
    participants_availability int,
    FOREIGN KEY(user_id) REFERENCES Users(user_id),
    PRIMARY KEY(view_id)
);

CREATE TABLE Events (
    event_title varchar(40),
    event_creator int,
    view_id int,
    admin_id int,
    event_description varchar(255),
    event_address varchar(255),
    event_start_date_time DATETIME,
    event_end_date_time DATETIME,
    FOREIGN KEY(admin_id) REFERENCES Admins(admin_id),
    FOREIGN KEY(view_id) REFERENCES Participants(view_id),
    FOREIGN KEY(event_start_date_time) REFERENCES Calendar(event_start_date_time),
    FOREIGN KEY(event_creator) REFERENCES Users(user_id)
);