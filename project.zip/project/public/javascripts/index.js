const months = ["JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"];

var app = new Vue({
    el: '#app',
    data: {
        show_create_event_box: false,
        month_index: 5,
        month: months[5],
        year: 2022,
        show_events_sidebar: false,
        show_event_details: false
    },
    methods: {
        collapse_sidebar: function(){
            document.querySelector(".events_sidebar").style.display = "none";
        },
        update_month: function(action){
            // decrement or increment month
            if (action == -1){
                this.month_index--;
            }else{
                this.month_index++;
            }
            // if index out of bounds, wrap around
            if (this.month_index < 0){
                this.month_index = 11;
                this.year--;
            }
            else if (this.month_index > 11){
                this.month_index = 0;
                this.year++;
            }
            // update calendar
            this.month = months[this.month_index];
            this.generate_calendar();
        },
        update_year: function(action){
            if (action == -1){
                this.year--;
            }else{
                this.year++;
            }
            this.generate_calendar();
        },
        // CONSTRUCT CALENDAR DYNAMICALLY
        generate_calendar: function(){

            // and determine at which day does the 1st start
            var first_day = new Date(this.year, this.month_index, 1);
            const first_day_index = first_day.getDay();

            // and determine the last date number
            var last_day = new Date(this.year, this.month_index + 1, 0);
            const last_day_index = last_day.getDate();

            const calendar_dates = document.querySelector(".calendar-dates");
            // populate slot 0 -- 1st day index - 1 with empty divs
            let date_div = '';
            for (let i=0;i<first_day_index;i++){
                date_div += `<div></div>`;
            }

            // start populating the calendar with the dates of the month
            for (let i=1;i<=last_day_index;i++){
                date_div += `<div class="date">${i}</div>`;
                calendar_dates.innerHTML = date_div;
            }

            var year = this.year;
            var month = this.month;

            // add an event listener so that when a date is selected, it is highlighted and a sidebar is visible
            $(document).ready(function(){
                $(".date").click(function(){
                    // highlight date
                    $(this).addClass("date-selected").siblings().removeClass("date-selected");
                    // show events in that date
                    document.querySelector(".events_sidebar").style.display = "block";
                    // update sidebar header to indicate selected date
                    var date = $(this).text();
                    document.querySelector(".sidebar_date").innerText = date + " " + month + " " + year;
                })
            });
        },

        // PUT ALL THE EVENT OF THE USER TO THE SIDEBAR
        generate_events_sidebar: function(){
            // should be where we get the data from database

            // insert event details to event sidebar div
            const event_content = document.querySelector(".sidebar_contents");
            let event = ``;
            for (let i=0;i<3;i++){
                event += `<div class="event">
                <button id="event_name" class="collapsible">Test</button>
                <div class="event_box">
                  <div class="event_table">
                    <table class="event_details">
                      <tr>
                        <td>Start Time:</td>
                        <td>10:30</td>
                      </tr>
                      <tr>
                        <td>End Time:</td>
                        <td>11:30</td>
                      </tr>
                      <tr>
                        <td>Location:</td>
                        <td>Uni Adelaide</td>
                      </tr>
                      <tr>
                        <td>Attendees:</td>
                        <td><div class="email">example@gmail.com</div><div class="email">example@gmail.com</div></td>
                      </tr>
                    </table>
                  </div>
                  <div class="edit_event_box">
                    <button id="edit_event_button" class="create_event_buttons button">Edit</button>
                  </div>
                </div>
              </div>`;
            }
            event_content.innerHTML = event;

            // add event listener to display event content when its title is pressed
            $(document).ready(function(){
                $(".collapsible").click(function(){
                    // change to active state
                    this.classList.toggle("shown_event");
                    // toggle events in that date
                    var event_content = this.nextElementSibling;
                    if (event_content.style.display === "table"){
                        console.log("showing..");
                        event_content.style.display = "none";
                    }else{
                        console.log("hiding..");
                        event_content.style.display = "table";
                    }
                })
            });
        }
    },
    computed:{
        show_events(){
            console.log(this.show_events_sidebar);
            return this.show_events_sidebar;
        }
    }
});

document.getElementById("index-body").onload = app.generate_calendar();
document.getElementById("index-body").onload = app.generate_events_sidebar();
document.getElementById("app").hidden = false;



